package com.codingdojo.mealplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealplanApplication {

    public static void main(String[] args) {
        SpringApplication.run(MealplanApplication.class, args);
    }

}
